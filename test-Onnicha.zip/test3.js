var a=100;
var b=2.5;
var c="A";
var d="B";
var e="C"+5;

console.log(a+b+ " " +c+d+ " " + e);
